import json
from src.logging_config import configure_logging, log_event

def test_log_event_writes_json_to_isolated_path(tmp_path):
    logger = configure_logging(tmp_path / "isolated-logs")
    log_event(logger, "unit_test_event", country="India")
    for handler in logger.handlers:
        handler.flush()
    path = tmp_path / "isolated-logs" / "api.log"
    assert path.exists()
    record = json.loads(path.read_text(encoding="utf-8").strip().splitlines()[-1])
    assert record["event"] == "unit_test_event"
    assert record["country"] == "India"
    assert not (tmp_path / "production-logs" / "api.log").exists()
