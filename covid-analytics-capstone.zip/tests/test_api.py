from fastapi.testclient import TestClient
from src import api

def test_health_and_countries(isolated_app):
    client = TestClient(api.app)
    assert client.get("/health").status_code == 200
    response = client.get("/countries")
    assert response.status_code == 200
    assert "India" in response.json()["countries"]

def test_country_specific_prediction(isolated_app):
    response = TestClient(api.app).get("/predict", params={"country": "India", "days": 3})
    assert response.status_code == 200
    body = response.json()
    assert body["scope"] == "country"
    assert body["country"] == "India"
    assert len(body["forecast"]) == 3

def test_combined_prediction_and_validation(isolated_app):
    client = TestClient(api.app)
    response = client.get("/predict", params={"days": 2})
    assert response.status_code == 200
    assert response.json()["scope"] == "all_countries_combined"
    assert len(response.json()["forecast"]) == 2
    assert client.get("/predict", params={"days": 31}).status_code == 422
    assert client.get("/predict", params={"country": "Atlantis"}).status_code == 404

def test_metrics_endpoint(isolated_app):
    client = TestClient(api.app)
    client.get("/health")
    result = client.get("/metrics").json()
    assert result["requests"] >= 2
    assert "average_latency_ms" in result
