import pandas as pd
from src.model import prepare_country_frame, build_models, fit_best_model

def test_feature_engineering_produces_expected_features():
    df = pd.DataFrame({"date": pd.date_range("2024-01-01", periods=20),
                       "new_cases": range(1, 21)})
    prepared = prepare_country_frame(df)
    assert {"lag_1", "lag_2", "lag_3", "rolling_7", "day_index"}.issubset(prepared.columns)
    assert len(prepared) > 0
    assert (prepared["new_cases"] >= 0).all()

def test_multiple_models_are_defined():
    assert {"linear_regression", "random_forest"} == set(build_models())

def test_model_can_fit_and_predict():
    rows = []
    for country in ["India", "France"]:
        for i in range(30):
            rows.append({"country": country, "date": (pd.Timestamp("2024-01-01") + pd.Timedelta(days=i)),
                         "new_cases": i * 3 + 2})
    name, model = fit_best_model(pd.DataFrame(rows))
    assert name in {"linear_regression", "random_forest"}
    assert model.predict([[1, 2, 3, 2, 10]]).shape == (1,)
