import os
import pytest
import pandas as pd
from pathlib import Path
from src import api

@pytest.fixture
def isolated_app(tmp_path, monkeypatch):
    data_path = tmp_path / "test_data.csv"
    rows = []
    for country, factor in [("India", 1.0), ("France", 0.5)]:
        for i in range(35):
            rows.append({"country": country, "date": (pd.Timestamp("2024-01-01") + pd.Timedelta(days=i)).date().isoformat(),
                         "new_cases": max(1, int((i + 2) * factor * 10))})
    pd.DataFrame(rows).to_csv(data_path, index=False)
    model_path = tmp_path / "test_model.joblib"
    from src.train import train
    train(data_path=data_path, model_path=model_path, artifacts_dir=tmp_path / "artifacts")
    monkeypatch.setattr(api, "DATA_PATH", data_path)
    monkeypatch.setattr(api, "MODEL_PATH", model_path)
    monkeypatch.setattr(api, "LOG_DIR", tmp_path / "logs")
    api.logger = __import__("src.logging_config", fromlist=["configure_logging"]).configure_logging(tmp_path / "logs")
    api.METRICS.update({"requests": 0, "errors": 0, "latency_ms_total": 0.0, "predictions": 0})
    return data_path, model_path
