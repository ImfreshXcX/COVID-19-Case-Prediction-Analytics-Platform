import json
from pathlib import Path
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from src.config import DATA_PATH, MODEL_PATH
from src.model import FEATURES, fit_best_model, train_and_evaluate

def train(data_path=None, model_path=None, artifacts_dir=None):
    data_path = Path(data_path or DATA_PATH)
    model_path = Path(model_path or MODEL_PATH)
    artifacts_dir = Path(artifacts_dir or model_path.parent)
    df = pd.read_csv(data_path)
    required = {"country", "date", "new_cases"}
    if not required.issubset(df.columns):
        raise ValueError(f"Dataset must include columns: {sorted(required)}")
    data, results = train_and_evaluate(df)
    best_name, model = fit_best_model(df)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "model_name": best_name, "features": FEATURES}, model_path)
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    (artifacts_dir / "model_metrics.json").write_text(json.dumps({"selected_model": best_name, "results": results}, indent=2))
    result_df = pd.DataFrame(results).sort_values("mae")
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar(result_df["model"], result_df["mae"])
    ax.set_title("Model comparison: MAE (lower is better)")
    ax.set_ylabel("Mean absolute error")
    ax.tick_params(axis="x", rotation=15)
    fig.tight_layout()
    fig.savefig(artifacts_dir / "model_comparison.png", dpi=140)
    plt.close(fig)
    print(f"Selected {best_name}; saved model to {model_path}")
    return {"selected_model": best_name, "results": results}
if __name__ == "__main__":
    train()
