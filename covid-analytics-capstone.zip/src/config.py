import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = Path(os.getenv("DATA_PATH", ROOT / "data" / "covid_demo.csv"))
MODEL_PATH = Path(os.getenv("MODEL_PATH", ROOT / "artifacts" / "model.joblib"))
LOG_DIR = Path(os.getenv("LOG_DIR", ROOT / "logs"))
