from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from src.config import DATA_PATH, MODEL_PATH

def create_eda(data_path=None, output_dir=None):
    data_path = Path(data_path or DATA_PATH)
    output_dir = Path(output_dir or MODEL_PATH.parent)
    output_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(data_path)
    df["date"] = pd.to_datetime(df["date"])
    df["new_cases"] = pd.to_numeric(df["new_cases"], errors="coerce").fillna(0).clip(lower=0)
    top = df.groupby("country")["new_cases"].sum().nlargest(8).index
    fig, ax = plt.subplots(figsize=(9, 5))
    for country in top:
        series = df[df.country == country].sort_values("date")
        ax.plot(series.date, series.new_cases.rolling(7, min_periods=1).mean(), label=country)
    ax.set_title("Seven-day smoothed new cases by country")
    ax.set_ylabel("New cases (7-day mean)")
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(output_dir / "country_trends.png", dpi=140)
    plt.close(fig)
    totals = df.groupby("country")["new_cases"].sum().sort_values(ascending=False).head(10)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    totals.plot(kind="bar", ax=ax)
    ax.set_title("Reported new cases by country (dataset totals)")
    ax.set_ylabel("Total")
    fig.tight_layout()
    fig.savefig(output_dir / "country_totals.png", dpi=140)
    plt.close(fig)
    return [output_dir / "country_trends.png", output_dir / "country_totals.png"]
if __name__ == "__main__":
    print(create_eda())
