from datetime import datetime, timedelta
from pathlib import Path
import json
import time
import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from src.config import DATA_PATH, MODEL_PATH, LOG_DIR
from src.logging_config import configure_logging, log_event
from src.model import FEATURES, prepare_country_frame

app = FastAPI(title="COVID-19 Case Prediction API", version="1.0.0",
              description="Educational country-level trend analytics and next-day case estimates.")
logger = configure_logging()
METRICS = {"requests": 0, "errors": 0, "latency_ms_total": 0.0, "predictions": 0}

def load_data():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Data file not found: {DATA_PATH}")
    df = pd.read_csv(DATA_PATH)
    if not {"country", "date", "new_cases"}.issubset(df.columns):
        raise ValueError("Data must contain country, date, new_cases columns.")
    return df

def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Model file not found: {MODEL_PATH}. Run `python -m src.train`.")
    return joblib.load(MODEL_PATH)

@app.middleware("http")
async def monitor_requests(request: Request, call_next):
    start = time.perf_counter()
    METRICS["requests"] += 1
    try:
        response = await call_next(request)
        if response.status_code >= 400:
            METRICS["errors"] += 1
        return response
    except Exception:
        METRICS["errors"] += 1
        raise
    finally:
        elapsed = (time.perf_counter() - start) * 1000
        METRICS["latency_ms_total"] += elapsed
        log_event(logger, "http_request", method=request.method, path=request.url.path, latency_ms=round(elapsed, 2))

@app.get("/health")
def health():
    return {"status": "ok", "data_available": DATA_PATH.exists(), "model_available": MODEL_PATH.exists()}

@app.get("/countries")
def countries():
    try:
        df = load_data()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return {"countries": sorted(df["country"].dropna().astype(str).unique().tolist())}

def forecast_group(group, bundle, days):
    group = group.copy()
    group["date"] = pd.to_datetime(group["date"], errors="coerce")
    group["new_cases"] = pd.to_numeric(group["new_cases"], errors="coerce").fillna(0).clip(lower=0)
    group = group.dropna(subset=["date"]).sort_values("date")
    if group.empty:
        return []
    hist = group["new_cases"].rolling(7, min_periods=1).mean().tolist()
    dates = group["date"].tolist()
    output = []
    model = bundle["model"]
    for step in range(days):
        last = len(hist)
        if last < 4:
            estimate = max(0.0, hist[-1])
        else:
            features = pd.DataFrame([{
                "lag_1": hist[-1], "lag_2": hist[-2], "lag_3": hist[-3],
                "rolling_7": float(np.mean(hist[-7:])), "day_index": last
            }], columns=FEATURES)
            estimate = max(0.0, float(model.predict(features)[0]))
        next_date = (pd.Timestamp(dates[-1]) + timedelta(days=step+1)).date().isoformat()
        output.append({"date": next_date, "predicted_new_cases": round(estimate, 2)})
        hist.append(estimate)
    return output

@app.get("/predict")
def predict(country: str | None = None, days: int = 7):
    if days < 1 or days > 30:
        raise HTTPException(status_code=422, detail="days must be between 1 and 30")
    try:
        df, bundle = load_data(), load_model()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    if country:
        subset = df[df["country"].astype(str).str.casefold() == country.casefold()]
        if subset.empty:
            raise HTTPException(status_code=404, detail=f"Country not found: {country}")
        forecasts = forecast_group(subset, bundle, days)
        METRICS["predictions"] += len(forecasts)
        log_event(logger, "prediction", country=country, days=days, count=len(forecasts))
        return {"scope": "country", "country": country, "model": bundle["model_name"], "forecast": forecasts}
    # Aggregate means the sum of country-level forecasts per day.
    by_country = []
    for name, group in df.groupby("country"):
        forecast = forecast_group(group, bundle, days)
        if forecast:
            by_country.append((name, forecast))
    combined = []
    for i in range(days):
        combined.append({"date": by_country[0][1][i]["date"],
                         "predicted_new_cases": round(sum(f[1][i]["predicted_new_cases"] for f in by_country), 2)})
    METRICS["predictions"] += len(combined)
    log_event(logger, "prediction", country="ALL", days=days, count=len(combined))
    return {"scope": "all_countries_combined", "country_count": len(by_country),
            "model": bundle["model_name"], "forecast": combined}

@app.get("/metrics")
def metrics():
    count = METRICS["requests"]
    return {**METRICS, "average_latency_ms": round(METRICS["latency_ms_total"] / count, 2) if count else 0.0}
