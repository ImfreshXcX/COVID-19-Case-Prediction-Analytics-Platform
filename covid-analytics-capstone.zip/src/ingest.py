import argparse
from pathlib import Path
import pandas as pd
from src.config import DATA_PATH

OWID_URL = "https://covid.ourworldindata.org/data/owid-covid-data.csv"

def ingest(source="auto", output_path=None):
    output = Path(output_path or DATA_PATH)
    output.parent.mkdir(parents=True, exist_ok=True)
    if source in ("auto", "owid"):
        try:
            df = pd.read_csv(OWID_URL, usecols=["location", "date", "new_cases"])
            df = df.dropna(subset=["location", "date"])
            df["new_cases"] = pd.to_numeric(df["new_cases"], errors="coerce").fillna(0).clip(lower=0)
            df = df.rename(columns={"location": "country"})
            df.to_csv(output, index=False)
            print(f"Saved {len(df)} rows from OWID to {output}")
            return output
        except Exception as exc:
            if source == "owid":
                raise RuntimeError(f"OWID ingestion failed: {exc}") from exc
            print(f"OWID unavailable ({exc}); retaining bundled demo data.")
    if not output.exists():
        raise FileNotFoundError(f"No data found at {output}. Run with --source owid or restore bundled demo CSV.")
    return output

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=["auto", "owid"], default="auto")
    parser.add_argument("--output", default=None)
    args = parser.parse_args()
    ingest(args.source, args.output)
