import json
import logging
import os
from pathlib import Path
from datetime import datetime, timezone

def configure_logging(log_dir=None):
    target = Path(log_dir or os.getenv("LOG_DIR", "logs"))
    target.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("covid_api")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    # Replace only handlers owned by this app logger to avoid duplicate test handlers.
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    handler = logging.FileHandler(target / "api.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)
    return logger

def log_event(logger, event, **fields):
    record = {"timestamp": datetime.now(timezone.utc).isoformat(), "event": event, **fields}
    logger.info(json.dumps(record, default=str))
