import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

FEATURES = ["lag_1", "lag_2", "lag_3", "rolling_7", "day_index"]

def prepare_country_frame(frame):
    df = frame.copy()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["new_cases"] = pd.to_numeric(df["new_cases"], errors="coerce").fillna(0).clip(lower=0)
    df = df.dropna(subset=["date"]).sort_values("date")
    df["new_cases"] = df["new_cases"].rolling(7, min_periods=1).mean()
    df["lag_1"] = df["new_cases"].shift(1)
    df["lag_2"] = df["new_cases"].shift(2)
    df["lag_3"] = df["new_cases"].shift(3)
    df["rolling_7"] = df["new_cases"].shift(1).rolling(7, min_periods=1).mean()
    df["day_index"] = np.arange(len(df))
    return df.dropna(subset=FEATURES + ["new_cases"]).copy()

def build_models():
    return {
        "linear_regression": make_pipeline(StandardScaler(), LinearRegression()),
        "random_forest": RandomForestRegressor(n_estimators=120, max_depth=8, random_state=42, n_jobs=1),
    }

def persistence_predict(frame):
    if frame.empty:
        return 0.0
    return float(max(0, frame["new_cases"].iloc[-1]))

def train_and_evaluate(df):
    rows = []
    prepared = []
    for country, group in df.groupby("country"):
        part = prepare_country_frame(group)
        if len(part) >= 10:
            prepared.append(part)
    if not prepared:
        raise ValueError("Not enough rows to train; each country needs at least 10 usable observations.")
    data = pd.concat(prepared, ignore_index=True)
    split = max(1, int(len(data) * 0.8))
    split = min(split, len(data) - 1)
    train, test = data.iloc[:split], data.iloc[split:]
    from sklearn.metrics import mean_absolute_error, mean_squared_error
    predictions = {"persistence_baseline": np.full(len(test), train["new_cases"].iloc[-1])}
    for name, model in build_models().items():
        model.fit(train[FEATURES], train["new_cases"])
        predictions[name] = np.maximum(0, model.predict(test[FEATURES]))
    for name, pred in predictions.items():
        rows.append({"model": name, "mae": float(mean_absolute_error(test["new_cases"], pred)),
                     "rmse": float(np.sqrt(mean_squared_error(test["new_cases"], pred)))})
    return data, rows

def fit_best_model(df):
    data = pd.concat([prepare_country_frame(g) for _, g in df.groupby("country")], ignore_index=True)
    if len(data) < 10:
        raise ValueError("Not enough data to train a model.")
    scores = []
    # Chronological holdout comparison. Fit candidate models on training split only.
    split = max(1, min(int(len(data) * .8), len(data)-1))
    train, test = data.iloc[:split], data.iloc[split:]
    from sklearn.metrics import mean_absolute_error
    for name, model in build_models().items():
        model.fit(train[FEATURES], train["new_cases"])
        pred = np.maximum(0, model.predict(test[FEATURES]))
        scores.append((mean_absolute_error(test["new_cases"], pred), name))
    best_name = min(scores)[1]
    best = build_models()[best_name]
    best.fit(data[FEATURES], data["new_cases"])
    return best_name, best
